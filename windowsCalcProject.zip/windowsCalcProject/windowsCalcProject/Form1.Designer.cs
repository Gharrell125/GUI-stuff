﻿namespace windowsCalcProject
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.PosOrNeg = new System.Windows.Forms.Button();
            this.Mod = new System.Windows.Forms.Button();
            this.Divide = new System.Windows.Forms.Button();
            this.One = new System.Windows.Forms.Button();
            this.AC = new System.Windows.Forms.Button();
            this.Four = new System.Windows.Forms.Button();
            this.Seven = new System.Windows.Forms.Button();
            this.Two = new System.Windows.Forms.Button();
            this.Five = new System.Windows.Forms.Button();
            this.Eight = new System.Windows.Forms.Button();
            this.Three = new System.Windows.Forms.Button();
            this.Six = new System.Windows.Forms.Button();
            this.Nine = new System.Windows.Forms.Button();
            this.Multiply = new System.Windows.Forms.Button();
            this.Subtract = new System.Windows.Forms.Button();
            this.Add = new System.Windows.Forms.Button();
            this.Zero = new System.Windows.Forms.Button();
            this.Decimal = new System.Windows.Forms.Button();
            this.Equals = new System.Windows.Forms.Button();
            this.Display = new System.Windows.Forms.TextBox();
            this.Separator = new System.Windows.Forms.Label();
            this.Input = new System.Windows.Forms.TextBox();
            this.Output = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // PosOrNeg
            // 
            this.PosOrNeg.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.PosOrNeg.Location = new System.Drawing.Point(135, 120);
            this.PosOrNeg.Name = "PosOrNeg";
            this.PosOrNeg.Size = new System.Drawing.Size(51, 28);
            this.PosOrNeg.TabIndex = 1;
            this.PosOrNeg.Text = "+/-";
            this.PosOrNeg.UseVisualStyleBackColor = false;
            this.PosOrNeg.Click += new System.EventHandler(this.PosOrNeg_Click);
            // 
            // Mod
            // 
            this.Mod.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Mod.Location = new System.Drawing.Point(235, 120);
            this.Mod.Name = "Mod";
            this.Mod.Size = new System.Drawing.Size(38, 28);
            this.Mod.TabIndex = 2;
            this.Mod.Text = "%";
            this.Mod.UseVisualStyleBackColor = false;
            this.Mod.Click += new System.EventHandler(this.Mod_Click);
            // 
            // Divide
            // 
            this.Divide.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Divide.Location = new System.Drawing.Point(338, 120);
            this.Divide.Name = "Divide";
            this.Divide.Size = new System.Drawing.Size(33, 28);
            this.Divide.TabIndex = 3;
            this.Divide.Text = "/";
            this.Divide.UseVisualStyleBackColor = false;
            this.Divide.Click += new System.EventHandler(this.Divide_Click);
            // 
            // One
            // 
            this.One.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.One.Location = new System.Drawing.Point(37, 177);
            this.One.Name = "One";
            this.One.Size = new System.Drawing.Size(38, 27);
            this.One.TabIndex = 4;
            this.One.Text = "1";
            this.One.UseVisualStyleBackColor = false;
            this.One.Click += new System.EventHandler(this.One_Click);
            // 
            // AC
            // 
            this.AC.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.AC.Location = new System.Drawing.Point(37, 120);
            this.AC.Name = "AC";
            this.AC.Size = new System.Drawing.Size(51, 28);
            this.AC.TabIndex = 0;
            this.AC.Text = "AC";
            this.AC.UseVisualStyleBackColor = false;
            this.AC.Click += new System.EventHandler(this.AC_Click);
            // 
            // Four
            // 
            this.Four.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Four.Location = new System.Drawing.Point(37, 231);
            this.Four.Name = "Four";
            this.Four.Size = new System.Drawing.Size(38, 27);
            this.Four.TabIndex = 5;
            this.Four.Text = "4";
            this.Four.UseVisualStyleBackColor = false;
            this.Four.Click += new System.EventHandler(this.Four_Click);
            // 
            // Seven
            // 
            this.Seven.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Seven.Location = new System.Drawing.Point(37, 288);
            this.Seven.Name = "Seven";
            this.Seven.Size = new System.Drawing.Size(38, 27);
            this.Seven.TabIndex = 6;
            this.Seven.Text = "7";
            this.Seven.UseVisualStyleBackColor = false;
            this.Seven.Click += new System.EventHandler(this.Seven_Click);
            // 
            // Two
            // 
            this.Two.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Two.Location = new System.Drawing.Point(135, 177);
            this.Two.Name = "Two";
            this.Two.Size = new System.Drawing.Size(38, 27);
            this.Two.TabIndex = 7;
            this.Two.Text = "2";
            this.Two.UseVisualStyleBackColor = false;
            this.Two.Click += new System.EventHandler(this.Two_Click);
            // 
            // Five
            // 
            this.Five.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Five.Location = new System.Drawing.Point(135, 231);
            this.Five.Name = "Five";
            this.Five.Size = new System.Drawing.Size(38, 27);
            this.Five.TabIndex = 8;
            this.Five.Text = "5";
            this.Five.UseVisualStyleBackColor = false;
            this.Five.Click += new System.EventHandler(this.Five_Click);
            // 
            // Eight
            // 
            this.Eight.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Eight.Location = new System.Drawing.Point(135, 288);
            this.Eight.Name = "Eight";
            this.Eight.Size = new System.Drawing.Size(38, 27);
            this.Eight.TabIndex = 9;
            this.Eight.Text = "8";
            this.Eight.UseVisualStyleBackColor = false;
            this.Eight.Click += new System.EventHandler(this.Eight_Click);
            // 
            // Three
            // 
            this.Three.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Three.Location = new System.Drawing.Point(235, 177);
            this.Three.Name = "Three";
            this.Three.Size = new System.Drawing.Size(38, 27);
            this.Three.TabIndex = 10;
            this.Three.Text = "3";
            this.Three.UseVisualStyleBackColor = false;
            this.Three.Click += new System.EventHandler(this.Three_Click);
            // 
            // Six
            // 
            this.Six.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Six.Location = new System.Drawing.Point(235, 231);
            this.Six.Name = "Six";
            this.Six.Size = new System.Drawing.Size(38, 27);
            this.Six.TabIndex = 11;
            this.Six.Text = "6";
            this.Six.UseVisualStyleBackColor = false;
            this.Six.Click += new System.EventHandler(this.Six_Click);
            // 
            // Nine
            // 
            this.Nine.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Nine.Location = new System.Drawing.Point(235, 288);
            this.Nine.Name = "Nine";
            this.Nine.Size = new System.Drawing.Size(38, 27);
            this.Nine.TabIndex = 12;
            this.Nine.Text = "9";
            this.Nine.UseVisualStyleBackColor = false;
            this.Nine.Click += new System.EventHandler(this.Nine_Click);
            // 
            // Multiply
            // 
            this.Multiply.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Multiply.Location = new System.Drawing.Point(338, 288);
            this.Multiply.Name = "Multiply";
            this.Multiply.Size = new System.Drawing.Size(38, 27);
            this.Multiply.TabIndex = 13;
            this.Multiply.Text = "x";
            this.Multiply.UseVisualStyleBackColor = false;
            this.Multiply.Click += new System.EventHandler(this.Multiply_Click);
            // 
            // Subtract
            // 
            this.Subtract.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Subtract.Location = new System.Drawing.Point(338, 231);
            this.Subtract.Name = "Subtract";
            this.Subtract.Size = new System.Drawing.Size(38, 27);
            this.Subtract.TabIndex = 14;
            this.Subtract.Text = "-";
            this.Subtract.UseVisualStyleBackColor = false;
            this.Subtract.Click += new System.EventHandler(this.Subtract_Click);
            // 
            // Add
            // 
            this.Add.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Add.Location = new System.Drawing.Point(338, 177);
            this.Add.Name = "Add";
            this.Add.Size = new System.Drawing.Size(38, 27);
            this.Add.TabIndex = 15;
            this.Add.Text = "+";
            this.Add.UseVisualStyleBackColor = false;
            this.Add.Click += new System.EventHandler(this.Add_Click);
            // 
            // Zero
            // 
            this.Zero.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Zero.Location = new System.Drawing.Point(37, 346);
            this.Zero.Name = "Zero";
            this.Zero.Size = new System.Drawing.Size(136, 27);
            this.Zero.TabIndex = 16;
            this.Zero.Text = "0";
            this.Zero.UseVisualStyleBackColor = false;
            this.Zero.Click += new System.EventHandler(this.Zero_Click);
            // 
            // Decimal
            // 
            this.Decimal.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Decimal.Location = new System.Drawing.Point(235, 346);
            this.Decimal.Name = "Decimal";
            this.Decimal.Size = new System.Drawing.Size(33, 27);
            this.Decimal.TabIndex = 17;
            this.Decimal.Text = ".";
            this.Decimal.UseVisualStyleBackColor = false;
            this.Decimal.Click += new System.EventHandler(this.Decimal_Click);
            // 
            // Equals
            // 
            this.Equals.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Equals.Location = new System.Drawing.Point(338, 346);
            this.Equals.Name = "Equals";
            this.Equals.Size = new System.Drawing.Size(47, 27);
            this.Equals.TabIndex = 18;
            this.Equals.Text = "=";
            this.Equals.UseVisualStyleBackColor = false;
            this.Equals.Click += new System.EventHandler(this.Equals_Click);
            // 
            // Display
            // 
            this.Display.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Display.Location = new System.Drawing.Point(12, 26);
            this.Display.Multiline = true;
            this.Display.Name = "Display";
            this.Display.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.Display.Size = new System.Drawing.Size(634, 68);
            this.Display.TabIndex = 20;
            // 
            // Separator
            // 
            this.Separator.AutoSize = true;
            this.Separator.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Separator.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Separator.Location = new System.Drawing.Point(552, 48);
            this.Separator.Name = "Separator";
            this.Separator.Size = new System.Drawing.Size(93, 20);
            this.Separator.TabIndex = 22;
            this.Separator.Text = "--------------";
            // 
            // Input
            // 
            this.Input.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Input.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Input.Location = new System.Drawing.Point(26, 30);
            this.Input.Name = "Input";
            this.Input.Size = new System.Drawing.Size(614, 20);
            this.Input.TabIndex = 24;
            this.Input.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Output
            // 
            this.Output.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Output.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Output.Location = new System.Drawing.Point(26, 71);
            this.Output.Name = "Output";
            this.Output.Size = new System.Drawing.Size(614, 20);
            this.Output.TabIndex = 25;
            this.Output.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Form1
            // 
            this.BackColor = System.Drawing.SystemColors.ControlLight;
            this.ClientSize = new System.Drawing.Size(658, 391);
            this.Controls.Add(this.Output);
            this.Controls.Add(this.Input);
            this.Controls.Add(this.Separator);
            this.Controls.Add(this.Display);
            this.Controls.Add(this.Equals);
            this.Controls.Add(this.Decimal);
            this.Controls.Add(this.Zero);
            this.Controls.Add(this.Add);
            this.Controls.Add(this.Subtract);
            this.Controls.Add(this.Multiply);
            this.Controls.Add(this.Nine);
            this.Controls.Add(this.Six);
            this.Controls.Add(this.Three);
            this.Controls.Add(this.Eight);
            this.Controls.Add(this.Five);
            this.Controls.Add(this.Two);
            this.Controls.Add(this.Seven);
            this.Controls.Add(this.Four);
            this.Controls.Add(this.One);
            this.Controls.Add(this.Divide);
            this.Controls.Add(this.Mod);
            this.Controls.Add(this.PosOrNeg);
            this.Controls.Add(this.AC);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Name = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button PosOrNeg;
        private Button Mod;
        private Button Divide;
        private Button One;
        private Button AC;
        private Button Four;
        private Button Seven;
        private Button Two;
        private Button Five;
        private Button Eight;
        private Button Three;
        private Button Six;
        private Button Nine;
        private Button Multiply;
        private Button Subtract;
        private Button Add;
        private Button Zero;
        private Button Decimal;
        private Button Equals;
        private TextBox Display;
        private Label Separator;
        private TextBox Input;
        private TextBox Output;
    }
}